#include <iostream>
#include <vector>
#include <list>
#include <queue>
#include <limits>
using namespace std;


struct Status{

    int state = 0;
    int distance = numeric_limits<int>::max();
    int parent = -1;

};

struct VertexStatus{

  int vertexNumber;
  bool visite;
  long key;
  int parent;

};


struct Vertex{

   int ver ;
   int weight;

};

class Graph{

private:
    vector< list<Vertex> > adjacencyList;
    int vertexCounter;



public:
    // Constructor
    Graph(int v){
      vertexCounter = v;
      list<Vertex> li;

     for( int i = 0; i < vertexCounter; i++)
        adjacencyList.push_back(li);

    }

    // Destructor
    ~Graph(){}


      // add edge
       void addEdge( int i , int j, int weight){

            Vertex vertex;  //= new Vertex;

            vertex.ver = j;
            vertex.weight = weight;

           if( (i >= 0 && i < vertexCounter) && ( j >= 0 && j < vertexCounter) )
             adjacencyList[i].push_back(vertex);

          //   delete n;
      }

      //add Undirected edge
      void addUndirectedEdge(int i , int j, int weight){

          if( (i >= 0 && i < vertexCounter) && ( j >= 0 && j < vertexCounter) ){
            addEdge(i,j,weight);
            addEdge(j,i, weight);
          }
      }

      // isEdge

      bool isEdge(int i , int j){

            if( (i >= 0 && i < vertexCounter) && ( j >= 0 && j < vertexCounter) ){

                list<Vertex>::iterator point = adjacencyList[i].begin();

                while( point != adjacencyList[i].end() ){

                    if( point->ver == j ){
                        return true;
                    }

                    point++;
                }

                return false;
        }

      }

      //get weight

      int getWeight( int i , int j){

          if( (i >= 0 && i < vertexCounter) && ( j >= 0 && j < vertexCounter) ){

                list<Vertex>::iterator point = adjacencyList[i].begin();

                while( point != adjacencyList[i].end() ){

                    if( point->ver == j ){
                        return point->weight;
                    }
                    point++;
                }

                return 0;
          }

      }

      // remove edge

      /*void removeEdge(int vertex, int edge){

          list<int>::iterator point;

              if( vertex >=0 && vertex <= adjacencyList.size() ){
                point = adjacencyList[vertex].begin();

                while(point!= adjacencyList[vertex].end()){
                    if(edge == *point){
                        adjacencyList[vertex].erase(point);
                        break;
                    }
                    point++;
                }
              }
      }
       */

      // adjacency list
      /*void showAdjacencyList(int vertex){

            if( vertex >= 0 && vertex < adjacencyList.size() ){
                list<int>::iterator point;

                point = adjacencyList[vertex].begin();

                cout << "Adjacency list of [" << (char)(vertex+65) << "] : ";

                while( point != adjacencyList[vertex].end() ){

                    cout << " " << (char)(65+*point);
                    point++;
                }
              cout << endl;


            }
      }

       //Find out degree
       int findOutDegree(int vertex){
           return findDegree(vertex);

       }

       //find InDegree
       int findInDegree(int vertex){

             int inDegree = 0;

            if( vertex >= 0 && vertex < adjacencyList.size() ){
                list<int>::iterator point;

                for( int i = 0; i < adjacencyList.size(); i++){
                point = adjacencyList[i].begin();

                while( point != adjacencyList[i].end() ){

                    if( *point == vertex ){
                        inDegree++;
                    }

                    point++;
                }

                }
                return inDegree;

            }
       }

       //get edge

       bool isEdge(int i , int j){

          if( ( i >= 0 && i < vertexCounter) && ( j >= 0 && j < vertexCounter)){

               list<int>::iterator point = adjacencyList[i].begin();

               while(point != adjacencyList[i].end() ){

                   if(*point == j){
                    return true;
                   }
                   point++;
               }
                return false;
          }
       }


      //counting degree undirected graph
      int findDegree(int vertex){

            int counter = 0;

            if( vertex >= 0 && vertex < adjacencyList.size() ){
                list<int>::iterator point;

                point = adjacencyList[vertex].begin();


                while( point != adjacencyList[vertex].end() ){
                    counter++;
                    point++;
                }
                return counter;

            }
      }


      // Show all adjacency list
         void show(){

          list<int>:: iterator point;

         for( int i = 0; i < adjacencyList.size(); i++){

                showAdjacencyList(i);
            }
            cout << "\n";
         }



    // get nodes counter
    int getVertexNumber(){

        return adjacencyList.size();
    }

    //get vector
       vector < list<int> > getList(){
        return adjacencyList;
    }

    //BFS

    void BFS(Graph graph , int vertex){

          vector < list<int> > myVec = graph.getList();
          int vCounter = graph.getVertexNumber();
          Status *st = new Status[vCounter];
          int u;
          list<int>::iterator point;

          st[vertex].state = 1;
          st[vertex].distance = 0;
          st[vertex].parent = -1;

          queue<int> myQueue;
list<Vertex>
          myQueue.push(vertex);

          while( !myQueue.empty() ){

            u = myQueue.front();
            myQueue.pop();

            point = myVec[u].begin();  // get list pointer

            cout << "vertex: " << (char)(65+u) << " parent: " << (char)(65+st[u].parent) << " distance: " << st[u].distance << endl;

            while( point != myVec[u].end() ){

                        if( st[*point].state == 0){
                           st[*point].state = 1;
                           st[*point].distance = st[u].distance + 1;
                           st[*point].parent = u;
                           myQueue.push(*point);

                        }
                        point++;

            }

          }
        } // end of BFS

*/
         // show matrix

     void showMatrix(){

        list<Vertex>:: iterator point;

        for( int i = 0; i < adjacencyList.size(); i++){

            point = adjacencyList[i].begin();

            cout  << "Adjacency list of  "<< (char)(65+i) << " : " ;

            while( point != adjacencyList[i].end() ){

                cout << (char) (65 +(point->ver) ) << " ";
                point++;
            }

            cout << endl;
        }

     }

     int getVertexCounter(){
       return vertexCounter;
     }

     // prims algorithm

      // implementing minimum spanning tree using Prim's Algorithm
  /*
  *
  *
  */

  void MSTPrims(Graph &graph , int s){

       int vertex = graph.getVertexCounter();
       int u;

       vector<VertexStatus> myVec;

      // cout << vertex << endl;

       VertexStatus *status = new VertexStatus[vertex];

        for( int i = 0; i < vertex; i++){

             status[i].vertexNumber = i;
             status[i].visite = false;
             status[i].parent = -1;
             status[i].key = numeric_limits<long>::max();
        }

        status[s].key = 0;
        status[s].visite = true;


        for( int i = 0; i < vertex; i++){
            myVec.push_back(status[i]);
        }


        cout << "\n\nMinimum spanning tree is: " << endl;

        int n = 0;


        while( !myVec.empty() ){

            u = extractMin(myVec).vertexNumber;

            status[u].visite = true;



        //   if( n > 1 )
            cout << (char)(65+status[u].parent) << " -> " << (char)(65+u) << endl;

            n++;


            for( int v = 0; v < vertex; v++){

                if( isEdge(u,v)){

                    if( isIn(myVec,v) && ( getWeight(u,v) ) < status[v].key ){

                   //     cout << " " << (char)(65+v) << " key: " << getWeight(u,v) << endl;

                        status[v].key = getWeight(u,v);
                        status[v].parent = u;
                        modifyKey(myVec,v,status[v].key);
                    }

                }
            }

        }



  }

   // is? vertex in the list
    bool isIn(vector<VertexStatus> &myVec, int n){

          for( int i = 0; i < myVec.size(); i++){

              if( myVec[i].vertexNumber == n ){
                return true;
              }
          }

          return false;
    }

  // get vertex status

   VertexStatus extractMin(vector<VertexStatus> &myVec){

        int verKey;
        VertexStatus st;
        int n;

            verKey = myVec[0].key;
            st = myVec[0];
            n = 0;

           // cout << "Initialize: vertex = " << (char)(65+n) <<" key = " << verKey << endl;


        for( int i = 1; i < myVec.size(); i++){

            if( myVec[i].key < verKey ){

                verKey = myVec[i].key;
                st = myVec[i];
                n = i;
            }


        }

        //cout << "Min: vertex = " << (char)(65+n)  <<" key = " << verKey << endl << endl;


        vector<VertexStatus>::iterator point;

        point = myVec.begin();

        for( int i = 0; i < n; i++)
            point++;

        myVec.erase(point);

        return st;
    }

   //modify key


  void modifyKey(vector<VertexStatus> &myVec, int vertex, int key){

      for( int i = 0; i < myVec.size(); i++){

         if( myVec[i].vertexNumber == vertex ){

             myVec[i].key = key;
             break;
         }
      }

  }




};


int main()
{
     Graph graph(9);

    graph.addUndirectedEdge(0,1,10);
    graph.addUndirectedEdge(0,2,12);
    graph.addUndirectedEdge(1,3,8);
    graph.addUndirectedEdge(1,2,9);
    graph.addUndirectedEdge(2,4,3);
    graph.addUndirectedEdge(2,5,1);
    graph.addUndirectedEdge(3,4,7);
    graph.addUndirectedEdge(3,5,6);
    graph.addUndirectedEdge(3,6,8);
    graph.addUndirectedEdge(3,7,5);
    graph.addUndirectedEdge(4,5,3);
    graph.addUndirectedEdge(5,7,6);
    graph.addUndirectedEdge(6,7,9);
    graph.addUndirectedEdge(6,8,2);
    graph.addUndirectedEdge(7,8,11);


    graph.showMatrix();

    graph.MSTPrims(graph,0);


      return 0;
}
